required_vars=(
    "STAGE_BUCKET"
    "STAGE_FOLDER"
    "STAGE_ACCESS_KEY"
    "STAGE_SECRET_KEY"
    "STAGE_ENDPOINT_URL"
    "STAGE_REGION"
    "FINAL_BUCKET"
    "FINAL_FOLDER"
    "FINAL_ACCESS_KEY"
    "FINAL_SECRET_KEY"
    "FINAL_ENDPOINT_URL"
    "FINAL_REGION"
    "SOURCE_BUCKET"
    "SOURCE_FINAL_FOLDER"
    "SOURCE_FOLDER"
    "SOURCE_ACCESS_KEY"
    "SOURCE_SECRET_KEY"
    "SOURCE_ENDPOINT_URL"
    "SOURCE_REGION"
    "SERVICE_ACCOUNT_ARN"
    "PVC_SIZE"
    "PVC_HISTORIC_SIZE"  
    "PVC_ONDEMAND_SIZE"
    "PVC_SPIKE_SIZE"
    "PVC_STORAGECLASS_NAME"
)

check_env_vars() {
    for var in "${required_vars[@]}"; do
        if [ -z "${!var}" ]; then
            echo "Environment variable $var is not set"
            exit 1
        fi
    done
}

# Export environment variables safely
set -a
source sample.env
set +a

# Check if required environment variables are set
check_env_vars

# Substitute environment variables in the YAML file
envsubst < episilia_values.yaml > episilia_values_env.yaml

# Run Helm install using the generated file (make sure to use checkv.yaml)
#helm install episilia episilia/episilia-spike -f episilia_values_env.yaml -n episilia --dry-run
helm install episilia episilia/episilia-spike -f episilia_values_env.yaml -n episilia
