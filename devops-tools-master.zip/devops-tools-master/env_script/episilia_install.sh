# Export environment variables safely
export $(cat sample.env | xargs)
# set -a
# source sample.env
# set +a

# # Check if required environment variables are set
# check_env_vars

# Substitute environment variables in the YAML file
envsubst < episilia_values.yaml > episilia_values_env.yaml

# Run Helm install using the generated file (make sure to use checkv.yaml)
helm install episilia episilia/episilia-spike -f episilia_values_env.yaml -n episilia --dry-run
#helm install episilia episilia/episilia-spike -f episilia_values_env.yaml -n episilia
