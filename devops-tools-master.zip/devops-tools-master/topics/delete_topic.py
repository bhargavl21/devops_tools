from kafka.admin import KafkaAdminClient

# Initialize KafkaAdminClient
admin_client = KafkaAdminClient(
    bootstrap_servers="146.190.9.219:9093", 
    client_id='test'
)

# List of topic names to delete
topic_names = [
    "check-index",
    "check-alert-out",
    "example_topic"
]

# Delete the topics
admin_client.delete_topics(topics=topic_names, timeout_ms=30000)
