from kafka.admin import KafkaAdminClient, NewTopic

# Initialize KafkaAdminClient
admin_client = KafkaAdminClient(
    bootstrap_servers="146.190.9.219:9093", 
    client_id='test'
)

# List of topic names
topic_names = [
    "check-index",
    "check-alert-out",
    "example_topic"
]

# Number of partitions and replication factor
num_partitions = 1
replication_factor = 1

# Create NewTopic instances for each topic name in the list
topic_list = [NewTopic(name=topic, num_partitions=num_partitions, replication_factor=replication_factor) for topic in topic_names]

# Create the topics
admin_client.create_topics(new_topics=topic_list, validate_only=False)
