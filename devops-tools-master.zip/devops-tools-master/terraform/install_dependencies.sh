#!/bin/sh
# Install Dependencies
sudo apt-get update 
sudo apt-get install -y gnupg \
software-properties-common \
unzip \
tar \
wget \
python3 \
python3-pip \
git \
openjdk-17-jdk \
openjdk-17-jre

## docker install
# Install required packages
sudo apt-get install -y ca-certificates curl

# Set up the Docker repository GPG key
sudo install -m 0755 -d /etc/apt/keyrings
sudo curl -fsSL https://download.docker.com/linux/ubuntu/gpg -o /etc/apt/keyrings/docker.asc
sudo chmod a+r /etc/apt/keyrings/docker.asc

# Add Docker's official GPG key
echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.asc] https://download.docker.com/linux/ubuntu \
  $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | \
  sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

# Update the package index again after adding Docker repository
sudo apt-get update -y

# Install Docker packages
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# Adjust permissions for Docker socket
sudo chmod 666 /var/run/docker.sock

# Test Docker installation
docker run hello-world

#doctl install
cd ~
wget https://github.com/digitalocean/doctl/releases/download/v1.110.0/doctl-1.110.0-linux-amd64.tar.gz
tar xf ~/doctl-1.110.0-linux-amd64.tar.gz
sudo mv ~/doctl /usr/local/bin

## kubectl
   curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
   curl -LO "https://dl.k8s.io/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl.sha256"
echo "$(cat kubectl.sha256)  kubectl" | sha256sum --check
sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl
chmod +x kubectl
mkdir -p ~/.local/bin
mv ./kubectl ~/.local/bin/kubectl
kubectl version --client

# aws
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip
sudo ./aws/install
./aws/install -i /usr/local/aws-cli -b /usr/local/bin
aws --version

# #python-kafka
pip3 install kafka-python

# kcat (formerly kafkacat)
sudo apt-get install -y libssl-dev libcurl4-openssl-dev
sudo apt-get install -y kcat

# Verify kcat installation
kcat -V


#kafkacat
sudo apt install -y kafkacat
wget https://dlcdn.apache.org/kafka/3.7.1/kafka_2.13-3.7.1.tgz
tar -xvf kafka_2.13-3.7.1.tgz

# git repo clone

chmod 600 /home/ubuntu/.ssh/id_rsa
chmod 600 /home/ubuntu/.ssh/known_hosts
ssh-keyscan -H gitlab.com >> /home/ubuntu/.ssh/known_hosts

eval "$(ssh-agent -s)"
ssh-add /home/ubuntu/.ssh/id_rsa

GIT_SSH_COMMAND='ssh -o StrictHostKeyChecking=no' git clone git@gitlab.com:episilia/tools.git
cd /home/ubuntu/tools
export JAVA_HOME=/usr/lib/jvm/java-17-openjdk-amd64
export PATH=$PATH:$JAVA_HOME/bin
./gradlew build -x test